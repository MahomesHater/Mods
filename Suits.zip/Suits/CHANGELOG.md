## v1.1.0 More suits!
- Added two more awful suits

## v1.0.0 Release
- Release

</details>